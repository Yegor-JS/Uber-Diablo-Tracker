const express = require("express");
const app = express();
const axios = require("axios");

app.use(express.static("./public"));

const fetchData = async () => {
  const response = await axios.get("https://diablo2.io/dclone_api.php?", {
    params: {
      sk: "r",
    },
  });
  allRegions = response.data;
  // console.log(allRegions);
  return allRegions;
};

let currentData = null;
async function collectDataOnceInAMinute() {
  currentData = await fetchData();
  setTimeout(() => {
    collectDataOnceInAMinute();
  }, 60000);
}
collectDataOnceInAMinute();

// УБЕЖДАЮСЬ, ЧТО КУРРЕНТ ДЕЙТА РАБОТАЕТ. РАБОТАЕТ!
// async function printCurrentData() {
//   setTimeout(() => {
//     console.log("КУРРЕНТ ДАТА", currentData);
//   }, 5000);
// };

// printCurrentData();

app.get("/api/data", async (req, res) => {
//  console.log(req.body, "ТЕЛО");
// ПОЧЕМУ ЭТА СТРОЧКА НЕ РАБОТАЕТ?
  const data = currentData;
  res.send(data);
//  send only data!!!! not markup!!!!
});

// app.get("/api/data", async (_, res) => {
//   const data = await fetchData();
//   res.send(data);
//   console.log(data);
// });

app.listen(3000, () => {
  // console.log("listening");
});

// console.log(fetchData());
